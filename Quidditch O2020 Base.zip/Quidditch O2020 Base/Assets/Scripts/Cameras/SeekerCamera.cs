﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SeekerCamera : MonoBehaviour
{
    public Transform Seeker;
    public Vector3 Offset;

	// Use this for initialization
	void Start ()
    {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
